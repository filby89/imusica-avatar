class PitchVolumeOrgan {
	constructor() {

	}
	refresh(data) {

		this.JointType = Object.freeze({
		  0: 'SpineBase',
		  1: 'SpineMid',
		  2: 'Neck',
		  3: 'Head',
		  4: 'ShoulderLeft',
		  5: 'ElbowLeft',
		  6: 'WristLeft',
		  7: 'HandLeft',
		  8: 'ShoulderRight',
		  9: 'ElbowRight',
		  10: 'WristRight',
		  11: 'HandRight',
		  12: 'HipLeft',
		  13: 'KneeLeft',
		  14: 'AnkleLeft',
		  15: 'FootLeft',
		  16: 'HipRight',
		  17: 'KneeRight',
		  18: 'AnkleRight',
		  19: 'FootRight',
		  20: 'SpineShoulder',
		  21: 'HandTipLeft',
		  22: 'ThumbLeft',
		  23: 'HandTipRight',
		  24: 'ThumbRight'
		});
	}

// is there any other Math.Abs????
                                    // calculate PITCH
                                    double offset = Math.Abs(yH3DPos - yN3DPos);
                                    double y_lowerbound = Math.Abs(ySB3DPos - offset);
                                    double y_upperbound = Math.Abs(yH3DPos + offset);
                                    
                                    double max_dist = Math.Abs(yH3DPos + offset - (ySB3DPos - offset));
                                    //Console.WriteLine("yH3DPos: " + yH3DPos);
                                    //Console.WriteLine("ySB3DPos: " + ySB3DPos);
                                    double step = max_dist / 8;
                                    double LHbin = Math.Floor((yLH3DPos - y_lowerbound) / step);
                                    LHbin = LHbin < 0 ? 0 : LHbin;
                                    LHbin = LHbin > 7 ? 7 : LHbin;

                                    double RHbin = Math.Floor((yRH3DPos - y_lowerbound) / step);
                                    RHbin = RHbin < 0 ? 0 : RHbin;
                                    RHbin = RHbin > 7 ? 7 : RHbin;
                                    //Console.WriteLine(LHbin);
                                    //Console.WriteLine(RHbin);
                                    
                                   
                                    //calculate volume
                                    double offsetVol = Math.Abs(xShR3DPos - xShL3DPos);
                                    //Console.WriteLine("xShR3DPos: " + xShR3DPos);
                                    //Console.WriteLine("xShL3DPos: " + xShL3DPos);                                   

                                    double max_distVol = Math.Abs(4 * offsetVol); 
                                   //Console.WriteLine("max_distVol: " + max_distVol);
                                    double stepVol = max_distVol / 30;
                                    double LHbinVol = Math.Floor(Math.Abs(xLH3DPos - xSM3DPos) / stepVol); //Math.Floor
                                    LHbinVol = LHbinVol < 0 ? 0 : LHbinVol;
                                    LHbinVol = LHbinVol > 15 ? 15 : LHbinVol;

                                    double RHbinVol = Math.Floor(Math.Abs(xRH3DPos - xSM3DPos) / stepVol);
                                    RHbinVol = RHbinVol < 0 ? 0 : RHbinVol;
                                    RHbinVol = RHbinVol > 15 ? 15 : RHbinVol;
                                    //Console.WriteLine("offsetVol: " + offsetVol);
                                    //Console.WriteLine("StepVol: " + stepVol);
                                    Console.WriteLine("LHbinVol: " + LHbinVol);
                                    Console.WriteLine("RHbinVol: " + RHbinVol);

                                    //send bins
                                    bin2send binData = new bin2send
                                    {
                                        lhbin = LHbin,
                                        rhbin = RHbin,
                                        lhbinVol = LHbinVol,
                                        rhbinVol = RHbinVol,
                                    };
                                    sendMessageWithContent(binData);
                              
                                    //calculate foot parameters
                                    FL_Dist = FLYprev - yFL3DPos;
                                    Console.WriteLine("FLYprev: " + FLYprev);
                                    FLYprev = yFL3DPos;
                                    Console.WriteLine("yFL3DPos: " + yFL3DPos);
                                    Console.WriteLine("FL_Dist: " + FL_Dist);

                                    FR_Dist = FRYprev - yFR3DPos;
                                    Console.WriteLine("FRYprev: " + FRYprev);
                                    FRYprev = yFR3DPos;
                                    Console.WriteLine("yFR3DPos: " + yFR3DPos);
                                    Console.WriteLine("FR_Dist: " + FR_Dist);
}